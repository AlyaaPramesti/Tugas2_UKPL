<?php

session_start();

if (!isset($_SESSION['nama_lengkap'])) {
  header("Location: index.php");
}
include "config.php";
require 'functions.php';
$inventaris = query("SELECT * FROM inventaris");

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="style1.css">
  <title>Halaman Inventaris</title>
</head>

<body>


  <nav class="topnav navbar-dark bg-blue">
    <p class="judul text-light">
      DAFTAR INVENTARIS BARANG<br>
      KANTOR BARANG
    </p>
  </nav>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse nav-link" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item active">
          <a class="nav-link text-dark" href="home.php">Beranda</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-dark" href="inventaris.php">Daftar Inventaris</a>
        </li>
      </ul>
    </div>
  </nav>


  <div class="body">
    <ul class="navbar-nav ms-auto">
      <li class="nav-item">
        <a type="button" class="nav-blue text-light" href="tambah.php">+ Tambah</a><br><br>
      </li>
    </ul>

    <table class="table" border="1" cellpadding="10" cellspacing="0">
      <tr>
        <th>No.</th>
        <th>Kode Barang</th>
        <th>Jumlah</th>
        <th>Satuan</th>
        <th>Tanggal Datang</th>
        <th>Harga Satuan</th>
        <th>Total Harga</th>
        <th>Aksi</th>
      </tr>
      <?php $i = 1;
      $totalinventaris = 0; ?>
      <?php foreach ($inventaris as $inven) : ?>
        <tr>
          <td><?= $i ?></td>
          <td><?= $inven["kode_barang"]; ?></td>
          <td><?= $inven["jumlah"]; ?></td>
          <td><?= $inven["satuan"]; ?></td>
          <td><?= $inven["tgl_datang"]; ?></td>
          <?php $num = $inven["harga"]; ?>
          <?php $numformat = number_format($num, 2, ",", "."); ?>
          <td>Rp. <?php echo $numformat; ?></td>
          <td>Rp. <?php $total = $inven["harga"] * $inven["jumlah"];
                  $totalFormat = number_format($total, 2, ",", ".");
                  echo $totalFormat; ?></td>
          <td>
            <a class="nav-blue text-light" href="edit.php?kode_barang=<?= $inven["kode_barang"]; ?>">Edit</a>
            <a class="nav-blue text-light" href="delete.php?kode_barang=<?= $inven["kode_barang"]; ?>" onclick="return confirm('Yakin ingin menghapus data?');">Hapus</a>
          </td>
        </tr>
        <?php $i++;
        $totalinventaris = $totalinventaris + $total; ?>
      <?php endforeach; ?>
    </table>
    <p align="center">Total Inventaris = Rp.<?php $totalinventarisformat = number_format($totalinventaris, 2, ",", ".");
                                            echo $totalinventarisformat; ?></p>
  </div>



  <div class="footer bg-blue">
    <p>Inventaris 2016</p>
  </div>

</body>

</html>