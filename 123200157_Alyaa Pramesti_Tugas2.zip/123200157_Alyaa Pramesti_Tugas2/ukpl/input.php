<?php 
if (!isset($_SESSION['nama_lengkap'])) {
    header("Location: index.php");
}
	include "config.php";

	$kode_barang = $_POST['kode_barang'];
	$jumlah = $_POST['jumlah'];
	$satuan = $_POST['satuan'];
	$tgl_datang = $_POST['tgl_datang'];
	$harga = $_POST['harga'];

	$query=mysqli_query($konek, "INSERT INTO inventaris VALUES ('$kode_barang',  '$jumlah', '$satuan', '$tgl_datang', '$harga')") or die(mysqli_error($conn));
	if($query){
		header("location:inventaris.php");
	}
	else{
		echo "Proses input gagal";
	}
