<?php
if (!isset($_SESSION['nama_lengkap'])) {
    header("Location: index.php");
}
require 'functions.php';

$kode_barang   = $_GET['kode_barang'];
$query="DELETE from inventaris where kode_barang='$kode_barang'";
mysqli_query($conn, $query);

header("location:inventaris.php");
?>