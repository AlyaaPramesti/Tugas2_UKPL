<?php

$conn = mysqli_connect("localhost", "root", "", "ukpl");

function query($query)
{
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}
	return $rows;
}

function tambah($data)
{
	global $conn;

	$kode_barang = htmlspecialchars($data["kode_barang"]);
	$jumlah = htmlspecialchars($data["jumlah"]);
	$satuan = htmlspecialchars($data["satuan"]);
	$tgl_datang = htmlspecialchars($data["tgl_datang"]);
	$harga = htmlspecialchars($data["harga"]);


	$query = "INSERT INTO inventaris VALUES 
			('$kode_barang', '$jumlah', '$satuan', '$tgl_datang', '$harga')";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function hapus($data)
{
	global $conn;

	// mysqli_query($conn, "DELETE FROM inventaris WHERE kode_barang = $kode_barang");
	return mysqli_affected_rows($conn);
}


function ubah($data)
{
	global $conn;

	$kode_barang = htmlspecialchars($data["kode_barang"]);
	$jumlah = htmlspecialchars($data["jumlah"]);
	$satuan = htmlspecialchars($data["satuan"]);
	$tgl_datang = htmlspecialchars($data["tgl_datang"]);
	$harga = htmlspecialchars($data["harga"]);

	$query = "UPDATE inventaris SET  
	 kode_barang = '$kode_barang',
	 jumlah = '$jumlah',
	 satuan = '$satuan',
	 tgl_datang = '$tgl_datang',
	 harga = '$harga'
			WHERE kode_barang = $kode_barang;
			";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}
