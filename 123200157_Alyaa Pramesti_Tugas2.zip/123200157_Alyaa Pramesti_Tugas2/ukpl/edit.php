<?php

session_start();

if (!isset($_SESSION['nama_lengkap'])) {
	header("Location: index.php");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="style1.css">
	<title>Halaman Ubah Data</title>
</head>

<body>
	<h1 class="bg-blue text-light text-center">Ubah Data Inventaris</h1>
	<?php
	include 'config.php';
	$kode_barang = $_GET['kode_barang'];
	$query = mysqli_query($konek, "SELECT * FROM inventaris WHERE kode_barang='$kode_barang'");
	while ($hasil = mysqli_fetch_array($query)) {
		echo "<form method='POST' action='prosesedit.php?kode_barang=$kode_barang'>"
	?>
		<table class="table" border="0">
			<form action="" method="post">
				<tr>
					<td><label for="kode_barang">Kode Barang</label></td>
					<td><input class="form-control" type="text" aria-label="default input example" name="kode_barang" value="<?php echo $hasil['kode_barang']; ?>" disabled></td>
				</tr>
				<tr>
					<td><label for="jumlah">Jumlah</label></td>
					<td><input class="form-control" type="text" aria-label="default input example" name="jumlah" value="<?php echo $hasil['jumlah']; ?>"></td>
				</tr>
				<tr>
					<td><label for="satuan">Umur Barang</label></td>
					<td><input class="form-control" type="number" aria-label="default input example" min="1" max="15" name="satuan" value="<?php echo $hasil['satuan']; ?>"></td>
				</tr>
				<tr>
					<td><label for="tgl_datang">Tanggal datang</label></td>
					<td><input class="form-control" type="date" name="tgl_datang" value="<?php echo $hasil['tgl_datang']; ?>"></td>
				</tr>
				<tr>
					<td><label for="harga">Harga</label></td>
					<td><input class="form-control" type="number" placeholder="Harga Satuan" aria-label="default input example" min="1000" name="harga" value="<?php echo $hasil['harga']; ?>"></td>
				</tr>
		</table>
		<center><button type="submit" class="bg-blue text-light">Ubah</button> <a href="inventaris.php"><button type="button" class="bg-blue text-light">Batal</button></a></center>
		<br>
		</form>
	<?php } ?>

	<div class="footer bg-blue">
		<p>Inventaris 2016</p>
	</div>
</body>

</html>