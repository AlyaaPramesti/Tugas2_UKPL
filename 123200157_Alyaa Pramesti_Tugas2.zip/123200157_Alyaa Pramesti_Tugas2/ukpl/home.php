<?php

session_start();

if (!isset($_SESSION['nama_lengkap'])) {
  header("Location: index.php");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="style1.css">
  <title>Halaman Home</title>
</head>

<body>

  <nav class="topnav navbar-dark bg-blue">
    <p class="judul text-light">
      DAFTAR INVENTARIS BARANG<br>
      KANTOR BARANG
    </p>
  </nav>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse nav-link" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item active">
          <a class="nav-link text-dark" href="home.php">Beranda</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-dark" href="inventaris.php">Daftar Inventaris</a>
        </li>
      </ul>
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active nav-blue text-light" href="logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </nav>


  <div class="container">
    <center>
      <h2>Selamat Datang</h2>
    </center>
  </div>

  <div class="nama">
    <?php echo "<h1>" . $_SESSION['nama_lengkap'] . "</h1>"; ?>
  </div>


  <div class="footer bg-blue">
    <p>Inventaris 2016</p>
  </div>

</body>

</html>