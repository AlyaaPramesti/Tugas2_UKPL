<?php
if (!isset($_SESSION['nama_lengkap'])) {
    header("Location: index.php");
}
	include "config.php";

	$kode_barang = $_GET['kode_barang'];
	$jumlah = $_POST['jumlah'];
	$satuan = $_POST['satuan'];
	$tgl_datang = $_POST['tgl_datang'];
	$harga = $_POST['harga'];

	$query=mysqli_query($konek, "UPDATE inventaris SET jumlah='$jumlah', satuan='$satuan', tgl_datang='$tgl_datang', harga='$harga' WHERE kode_barang='$kode_barang'");
	if($query){
		header("location:inventaris.php");
	}
	else{
		echo "Data gagal diubah";
	}
