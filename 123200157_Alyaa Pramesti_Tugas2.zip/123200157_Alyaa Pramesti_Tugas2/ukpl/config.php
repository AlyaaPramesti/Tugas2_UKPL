<?php 

$server = "localhost";
$user = "root";
$pass = "";
$database = "ukpl";

$konek = mysqli_connect($server, $user, $pass, $database);

if (!$konek) {
    die("<script>alert('Connection Failed!')</script>");
}
